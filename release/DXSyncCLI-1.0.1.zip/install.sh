#!/bin/bash
npm -g --production --no-optional install